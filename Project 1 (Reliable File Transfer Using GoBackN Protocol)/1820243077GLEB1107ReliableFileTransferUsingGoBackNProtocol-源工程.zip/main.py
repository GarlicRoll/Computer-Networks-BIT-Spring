import socket
import threading
import struct
import zlib
import time
import os.path
import tkinter as tk
from tkinter import filedialog
import logging

logger = logging.getLogger('example_logger')
logger.setLevel(logging.DEBUG)
file_handler = logging.FileHandler('logsrun.log')
file_handler.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)



stop_event = threading.Event()
interrupt_event = threading.Event()

def log_to_text_and_file(message):
    logger.debug(message)  # Writing the log to a file
    log_text.insert(tk.END, message + '\n')  # Displaying the log in the tk.Text widget
    log_text.see(tk.END)


def select_file():
    file_path = filedialog.askopenfilename()
    file_entry.delete(0, tk.END)
    file_entry.insert(0, file_path)

def apply_settings():
    UDPport_sender_entry.config(state=tk.DISABLED)
    UDPport_receiver_entry.config(state=tk.DISABLED)
    Timeout_entry.config(state=tk.DISABLED)
    SWsize_entry.config(state=tk.DISABLED)
    InitSeqNo_entry.config(state=tk.DISABLED)
    DataSize_entry.config(state=tk.DISABLED)
    ErrorRate_entry.config(state=tk.DISABLED)
    file_entry.config(state=tk.DISABLED)
    apply_button.config(state=tk.DISABLED)
    receiver.change_settings()
    sender.change_settings()
    apply_button.config(text="Saved", bg="green")
    root.after(3000, lambda: apply_button.config(text="Apply settings", bg="gray"))



def split_file_with_struct(file_path, chunk_size):
        chunks = []  # List for storing packed parts of a file
        with open(file_path, 'rb') as file:
            chunk_number = int(InitSeqNo_entry.get())
            for i in range(chunk_number):
                chunks.append(None)
            while True:
                # Reading the specified data size from a file
                data = file.read(chunk_size-8) #-4 -4 because 4 bytes per head and 4 bytes per hash
                if not data:
                    break
                # Calculate the CRC32 hash sum for part of the data
                hash_sum = zlib.crc32(data) & 0xFFFFFFFF
                # We pack the data along with the chunk number and hash sum into a binary string using struct.pack
                packed_data = struct.pack(f"II{len(data)}s", chunk_number,hash_sum, data)
                # Adding packed data to the list
                chunks.append(packed_data)
                chunk_number += 1
        return chunks

chunks_recived=[]

def ADD_chunks_recived(number, data):
    global chunks_recived
    try:
        chunks_recived[number] = data
    except IndexError:
        while len(chunks_recived) <= number:
            chunks_recived.append(None)
        chunks_recived[number] = data

def combine_chunks_to_file():
    global chunks_recived
    i=0
    with open(str(file_entry.get())+str("_recived"), 'wb') as file:
        for chunk in chunks_recived:
            if i<int(InitSeqNo_entry.get()):
                i+=1
                continue
            if chunk ==None:
                log_to_text_and_file("the file is not complete. A part is missing "+str(i))
            else:
                file.write(chunk)
            i+=1





def send_file_button_action():
    send_file_button.config(state=tk.DISABLED)
    file_path=str(file_entry.get())
    
    chunk_size = int(DataSize_entry.get())
    global chunks
    chunks = split_file_with_struct(file_path, chunk_size)

    log_to_text_and_file(str("Number of chunks:" + str(len(chunks))))
    global last_sent_packet
    last_sent_packet = 0
    global sender_thread
    sender_thread = threading.Thread(target=sender.send_data, args=(chunks,))
    sender_thread.start()



global last_sent_packet
last_sent_packet = 0

global GoBackN_p
GoBackN_p=0

class Sender:
    def __init__(self):
        self.host = '127.0.0.1'
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.Timeout = 1000
        self.background_wait_sanding = threading.Thread(target=self.wait_sending, args=(self.Timeout,))
        self.timer_running = False
        self.timer_breaked = threading.Event()
        self.GoBackN_event= False
        self.SendingWindowSize=1
        
    
    def change_settings(self):
        self.Timeout=int(Timeout_entry.get())/1000
        self.SendingWindowSize=int(SWsize_entry.get())
        self.port = int(UDPport_receiver_entry.get())
        
        self.socket.close()
        self.port=int(UDPport_receiver_entry.get())
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket_size=int(DataSize_entry.get())
        
        
        log_to_text_and_file(str("Sender data changed: UDP port " + str(self.port)))

    def send_data(self,data):
        i=int(InitSeqNo_entry.get())
        data_chunks_count=len(data)+int(InitSeqNo_entry.get())-1
        global last_sent_packet
        global GoBackN_p
        WindowCounter=0
        while True:
            if self.SendingWindowSize>1:
                if self.GoBackN_event:
                    self.GoBackN_event=False
                    p=GoBackN_p
                    log_to_text_and_file("in the next window resend the package "+str(p))
                    
                    WindowCounter=1
                if WindowCounter>0:
                    WindowCounter+=1
                if WindowCounter > self.SendingWindowSize:
                    log_to_text_and_file("+resending the package in a new window "+str(p))
                    
                    # log_to_text_and_file(str("заново отправляем пакет в новом окне" + str(p)))
                    # time.sleep(0.05)
                    chunk=data[p]
                    self.socket.sendto(chunk, (self.host, self.port))
                    WindowCounter=0



            if self.GoBackN_event:
                self.GoBackN_event=False
                i=GoBackN_p
                log_to_text_and_file("going to part "+ str(last_sent_packet+1))
            if i>=data_chunks_count:
                if last_sent_packet + 1 == data_chunks_count:
                    log_to_text_and_file("all packages have been sent")
                    break
                else:
                    if self.background_wait_sanding.is_alive():
                        self.background_wait_sanding.join()  # Wait for completion wait_sending
                        if self.timer_breaked.is_set():  # if the wait is interrupted
                            if last_sent_packet + 1 == data_chunks_count:
                                log_to_text_and_file("all packages have been sent")
                                break
                            if not self.GoBackN_event: #if there is no need to go back after the timeout, then skip the iteration
                                # print("после таймаута назад сходить не нужно, то пропускаем итерацию")
                                continue
                        else:
                            if last_sent_packet + 1 == data_chunks_count:
                                log_to_text_and_file("all packages have been sent")
                                break
                    else:                             
                        self.background_wait_sanding = threading.Thread(target=self.wait_sending, args=(self.Timeout,))
                        self.background_wait_sanding.start()
                        print("timer started after send")
                        self.timer_running = True
                        continue
                                                
                        
                        

            # если нужно сходить назад
            if self.GoBackN_event:
                self.GoBackN_event=False
                i=GoBackN_p
                log_to_text_and_file("going to part "+ str(last_sent_packet+1))



            time.sleep(0.02)
            chunk=data[i]
            self.socket.sendto(chunk, (self.host, self.port))
            log_to_text_and_file("PACKAGE SENT "+str(i))
            # print("ОТПРАВЛЕН ПАКЕТ ", i)
            
            if i==int(InitSeqNo_entry.get()):
                self.background_wait_sanding.start()
                # print("таймер запущен в самом начале")
                self.timer_running = True

            if not self.timer_running:
                self.background_wait_sanding = threading.Thread(target=self.wait_sending, args=(self.Timeout,))
                self.background_wait_sanding.start()
                # print("таймер запущен")
                self.timer_running = True
            
            i=i+1

        self.timer_breake()
            


    def wait_sending(self, seconds):
        global GoBackN_p
        self.timer_breaked.clear()
        self.timer_breaked.wait(seconds)
        if self.timer_breaked.is_set():
            # Actions if the event was interrupted. We received an answer
            # print("Ожидание прервано. last_sent_packet=", last_sent_packet)
            log_to_text_and_file("The wait is interrupted. last_sent_packet="+str(last_sent_packet))
        else:
            log_to_text_and_file("Timed out")
            # print("Истекло время ожидания")
            # нужно вернутся на N
            self.GoBackN_event=True
            GoBackN_p=last_sent_packet+1
        self.timer_running=False



    def timer_breake(self):
        # Setting up an interrupt event
        self.timer_breaked.set()

    def GoBackN_func(self):
        global GoBackN_p
        # print("нужно вернутся на n")
        log_to_text_and_file("need to go back to n")
        GoBackN_p=last_sent_packet+1 #помогает в решении проблемы отправки не того пакета
        self.GoBackN_event=True

class Receiver:

    def __init__(self):
        self.host = '127.0.0.1'
        self.port = 1
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.expected_seq_num = 0
        self.socket_size = 4096
        self.ErrorRate=0

    
    def receive_data(self):
        self.socket.bind((self.host, self.port))
        ii=0
        while True: 
            global last_sent_packet
            data, addr = self.socket.recvfrom(4096)
            if len(data)<=8:
                state,pucage_number=struct.unpack("bi", data)
                log_to_text_and_file("Recipient's response:" + str(state) +"package number:"+str(pucage_number))
              
                if state == 0:  # If the package arrived with an error
                    Sender.GoBackN_func(sender)
                    log_to_text_and_file("the package arrived with an error")
                    sender.timer_breake()
                else:
                    last_sent_packet=pucage_number
                    #if the package arrived ok. Disable response timeout
                    sender.timer_breake()

            else:
                
                data_head = struct.unpack(f"II{int(len(data)-8)}s", data)[0]
                data_crc = struct.unpack(f"II{int(len(data)-8)}s", data)[1]
                data_body = struct.unpack(f"II{int(len(data)-8)}s", data)[2]

                if self.ErrorRate > 0:
                    ii+=1
                    if ii % self.ErrorRate == 0:
                        log_to_text_and_file("Error by error rate")
                        data_crc=b'321'
                
                log_to_text_and_file(str("Received:" + str(data_head)))
                if data_crc == zlib.crc32(data_body) & 0xFFFFFFFF:
                    sender.socket.sendto(struct.pack('bi', True, int(data_head)), (sender.host, sender.port))
                    ADD_chunks_recived(data_head,data_body)
                    # еIf the data size is smaller than the split size. This is the last package. After successfully receiving the last package, we create a file from the received packages
                    if len(data_body) < int(DataSize_entry.get())-8:
                        log_to_text_and_file("THIS WAS THE LAST PACKET. BEGINNING TO CREATE A FILE "+str(len(data_body)))
                        # print("ЭТО БЫЛ ПОСЛЕДНИЙ ПАКЕТ. нАЧИНАЮ ФОРМИРОВАНИЕ ФААЙЛА", len(data_body))
                        time.sleep(3)
                        global chunks_recived
                        combine_chunks_to_file()
                else:
                    sender.socket.sendto(struct.pack('bi', False, int(data_head)), (sender.host, sender.port))
    

    def change_settings(self):
        self.ErrorRate=int(ErrorRate_entry.get())
        
        self.port = int(UDPport_sender_entry.get())
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket_size = int(DataSize_entry.get())
        receiver_thread = threading.Thread(target=receiver.receive_data)
        receiver_thread.start()
        log_to_text_and_file("Receiver data changed: UDP port " + str(self.port))




def main():
    global sender
    global receiver
    sender = Sender()
    receiver = Receiver()

if __name__ == "__main__":
    main()













root = tk.Tk()
root.title("Go-Back-N protocol project 1")

file_label = tk.Label(root, text="Select file to send:")
file_label.pack()

file_frame = tk.Frame(root)
file_frame.pack()

file_label_entry = tk.Label(file_frame, text="File:")
file_label_entry.pack(side=tk.LEFT)

file_entry = tk.Entry(file_frame, width=50)
file_entry.pack(side=tk.LEFT)

select_file_button = tk.Button(file_frame, text="Select a file", command=select_file)
select_file_button.pack(side=tk.RIGHT)

UDPport_sender_label = tk.Label(root, text="Sender UDP port:")
UDPport_sender_label.pack()

UDPport_sender_entry = tk.Entry(root)
UDPport_sender_entry.insert(0,"54321")
UDPport_sender_entry.pack()

UDPport_receiver_label = tk.Label(root, text="Recipient UDP port:")
UDPport_receiver_label.pack()

UDPport_receiver_entry = tk.Entry(root)
UDPport_receiver_entry.insert(0,"54322")
UDPport_receiver_entry.pack()

DataSize_label = tk.Label(root, text="DataSize:")
DataSize_label.pack()

DataSize_entry = tk.Entry(root)
DataSize_entry.insert(0,"1024")
DataSize_entry.pack()

ErrorRate_label = tk.Label(root, text="ErrorRate:")
ErrorRate_label.pack()

ErrorRate_entry = tk.Entry(root)
ErrorRate_entry.insert(0,"10")
ErrorRate_entry.pack()

SWsize_label = tk.Label(root, text="SWSize:")
SWsize_label.pack()

SWsize_entry = tk.Entry(root)
SWsize_entry.insert(0,"4")
SWsize_entry.pack()

Timeout_label = tk.Label(root, text="Timeout:")
Timeout_label.pack()

Timeout_entry = tk.Entry(root)
Timeout_entry.insert(0,"1000")
Timeout_entry.pack()

InitSeqNo_label = tk.Label(root, text="InitSeqNo:")
InitSeqNo_label.pack()

InitSeqNo_entry = tk.Entry(root)
InitSeqNo_entry.insert(0,"1")
InitSeqNo_entry.pack()


apply_button = tk.Button(root, text="Apply settings", command=apply_settings)
apply_button.pack()

send_file_button = tk.Button(root, text="Send file", command=send_file_button_action)
send_file_button.pack()


log_label = tk.Label(root, text="logs:")
log_label.pack()
log_text = tk.Text(root, height=10, width=50)
log_text.pack()

root.mainloop()
